Hi dev, Welcome!
This is a view category component

font link : <link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Archivo:wght@300&family=Orbitron:wght@500&display=swap" rel="stylesheet">

Fonts:
1)headings
font-family: 'Orbitron', sans-serif;
color: black

2)caption
font-family: 'Archivo', sans-serif;
color: #8888A0;

3)questions
font-family: 'Archivo', sans-serif;
color: black;

4)Add answers to each question
font-family: 'Archivo', sans-serif;
color: #8888A0;

upload your code on github or repl.it submit that as code link
and publish it to github pages or repl.it submit that link as live url.

You can add any effects like hover, animations etc.
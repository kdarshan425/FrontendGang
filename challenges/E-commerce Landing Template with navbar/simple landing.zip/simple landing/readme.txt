Hi dev, Welcome!
This is a simple landing section

font link:<link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@1,200;1,600;1,900&display=swap" rel="stylesheet">

Fonts:
1)LIMITED EDITION
font-family: 'Raleway', sans-serif;
color: black

2)all textfont-family: 'Raleway', sans-serif;
color: black

3)image caption
font-family: 'Raleway', sans-serif;
color: white

upload your code on github or repl.it submit that as code link
and publish it to github pages or repl.it submit that link as live url.
Hi dev, Welcome!
This is a view category component

font link:<link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@1,200;1,600;1,900&display=swap" rel="stylesheet">

Fonts:
1)Our products
font-family: 'Raleway', sans-serif;
color: gray

2)product heading
font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
color: black

3)percentage caption
font-family: 'Raleway', sans-serif;
color: black

upload your code on github or repl.it submit that as code link
and publish it to github pages or repl.it submit that link as live url.